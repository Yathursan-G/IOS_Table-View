//
//  customProfileViewController.swift
//  TravellerNoteBook
//
//  Created by Yathursan Gunaratnam on 10/11/20.
//  Copyright © 2020 Yathursan Gunaratnam. All rights reserved.
//

import UIKit

class customProfileViewController: UIViewController {
    @IBOutlet weak var nameLable: UILabel!
    
    @IBOutlet weak var addressLabel: UILabel!
    @IBOutlet weak var emailLable: UILabel!
    let a = UserDefaults.standard.value(forKey: "name") as! String
    let b = UserDefaults.standard.value(forKey: "address") as! String
    let c = UserDefaults.standard.value(forKey: "email") as! String
    override func viewDidLoad() {
        super.viewDidLoad()
        nameLable.text = a
        addressLabel.text = b
        emailLable.text = c
        //nameLable.text=UserDefaults.standard.value(forKey: "name") as? String
       // addressLabel.text=UserDefaults.standard.value(forKey: "address") as? String
       // emailLable.text=UserDefaults.standard.value(forKey: "email") as? String
        // Do any additional setup after loading the view.
    }
    
    
    @IBAction func viewMemory(_ sender: UIButton) {
    }
    
    @IBAction func addnewphoto(_ sender: UIButton) {
    }
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
