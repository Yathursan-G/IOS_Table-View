//
//  PlaceTableViewController.swift
//  TravellerNoteBook
//
//  Created by Yathursan Gunaratnam on 10/11/20.
//  Copyright © 2020 Yathursan Gunaratnam. All rights reserved.
//

import UIKit
var locations: location!
class PlaceTableViewController: UITableViewController, UISearchBarDelegate{
var loc=readData()
    var currentloc=readData()
    //var filteredData:[String]
    @IBOutlet var table: UITableView!
    @IBOutlet weak var searchBar: UISearchBar!
    override func viewDidLoad() {
        super.viewDidLoad()

        searchBar.delegate = self
        currentloc=loc
       // filteredData = details
    }

    // MARK: - Table view data source

    
    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        // #warning Incomplete implementation, return the number of rows
        return currentloc.count
    }

    
    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "cell", for: indexPath) as! PlaceTableViewCell
        cell.locationLabel.text=currentloc[indexPath.row].sitename
        cell.date.text=getDate(date:currentloc[indexPath.row].date)
        cell.ImageLabel.image = currentloc[indexPath.row].image
        return cell
    }
    override func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        locations = currentloc[indexPath.row]
        performSegue(withIdentifier: "final", sender: self)
    }

    

    
    func searchBar(_ searchBar: UISearchBar, textDidChange searchText: String) {
        guard !searchText.isEmpty else {
            currentloc = loc
            table.reloadData()
            return}
        currentloc = loc.filter({location -> Bool in
            location.sitename.lowercased().contains(searchText.lowercased()) || getDate(date: location.date).lowercased().contains(searchText.lowercased())
        })
        table.reloadData()
        
    }
    
}
