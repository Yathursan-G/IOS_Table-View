//
//  profileViewController.swift
//  TravellerNoteBook
//
//  Created by Yathursan Gunaratnam on 10/11/20.
//  Copyright © 2020 Yathursan Gunaratnam. All rights reserved.
//

import UIKit

class profileViewController: UIViewController {

    @IBOutlet weak var nameTextField: UILabel!
    @IBOutlet weak var lactionTextFiled: UILabel!
    @IBOutlet weak var mailTextField: UILabel!
    override func viewDidLoad() {
        super.viewDidLoad()
nameTextField.text = UserDefaults.standard.value(forKey: "name") as? String
        lactionTextFiled.text=UserDefaults.standard.value(forKey: "address") as? String
       mailTextField.text=UserDefaults.standard.value(forKey: "email") as? String
        // Do any additional setup after loading the view.
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
