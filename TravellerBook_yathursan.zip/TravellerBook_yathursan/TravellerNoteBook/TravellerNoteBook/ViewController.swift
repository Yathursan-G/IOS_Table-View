//
//  ViewController.swift
//  TravellerNoteBook
//
//  Created by Yathursan Gunaratnam on 7/11/20.
//  Copyright © 2020 Yathursan Gunaratnam. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var usernameTextField: UITextField!
    @IBOutlet weak var passwordTextField: UITextField!
    @IBOutlet weak var signup: UIButton!
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        signup.layer.cornerRadius=12
    }

    @IBAction func signup(_ sender: UIButton) {
        let userId = usernameTextField.text!
        let pass = passwordTextField.text!
        let username = UserDefaults.standard.value(forKey: "username") as! String
        let password = UserDefaults.standard.value(forKey: "password") as! String
        if (userId == username && pass == password)
        {
           performSegue(withIdentifier: "log1", sender: self)
            //alertMassage(msg: "Welcome", controller: self)
        }
        else
        {
            alertMassage(msg: "Check Your ID or Password", controller: self)
        }
    }
    
}

