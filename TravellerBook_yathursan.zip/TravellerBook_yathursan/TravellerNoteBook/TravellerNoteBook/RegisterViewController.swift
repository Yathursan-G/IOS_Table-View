//
//  RegisterViewController.swift
//  TravellerNoteBook
//
//  Created by Yathursan Gunaratnam on 9/11/20.
//  Copyright © 2020 Yathursan Gunaratnam. All rights reserved.
//

import UIKit
func alertMassage(msg: String, controller : UIViewController)
{
    let alert = UIAlertController(title: "", message: msg, preferredStyle: .alert)
    let action = UIAlertAction(title:"Okey", style:.default,  handler: {action in controller.dismiss(animated: true, completion: nil)})
    alert.addAction(action)
    controller.present(alert,animated: true,completion: nil)
}

class RegisterViewController: UIViewController {

    @IBOutlet weak var usernameTextField: UITextField!
    @IBOutlet weak var passwordTextField: UITextField!
    @IBOutlet weak var againPassTextField: UITextField!
    @IBOutlet weak var register: UIButton!
    @IBOutlet weak var nameTextField: UITextField!
    @IBOutlet weak var emailTextField: UITextField!
    @IBOutlet weak var addressTextField: UITextField!
    override func viewDidLoad() {
        super.viewDidLoad()
register.layer.cornerRadius=10
        // Do any additional setup after loading the view.
    }
    
    
    @IBAction func register(_ sender: UIButton) {
        let Cname=nameTextField.text!
        let Cmail=emailTextField.text!
        let Caddress=addressTextField.text!
        let userId=usernameTextField.text!
        let passWord=passwordTextField.text!
        let rePass=againPassTextField.text!
        if ( userId.isEmpty || passWord.isEmpty || rePass.isEmpty )
        {
            alertMassage(msg: "Enter Right Details", controller: self)
        }
        else
        {
            if( passWord == rePass)
            {   UserDefaults.standard.set(Cname, forKey: "name")
                UserDefaults.standard.set(Cmail, forKey: "email")
                UserDefaults.standard.set(Caddress,forKey: "address")
                UserDefaults.standard.set(userId, forKey: "username")
                UserDefaults.standard.set(passWord, forKey: "password")
               // alertMassage(msg: "Greate Enjoy !!", controller: self)
                performSegue(withIdentifier: "log2", sender: self)
            }
            else
            {
                alertMassage(msg: "Your password are not similar", controller: self)
            }
        }
        
    }
    
    
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
