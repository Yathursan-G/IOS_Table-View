//
//  FinalViewController.swift
//  TravellerNoteBook
//
//  Created by Yathursan Gunaratnam on 10/11/20.
//  Copyright © 2020 Yathursan Gunaratnam. All rights reserved.
//

import UIKit
func getDate(date : Date) -> String{
    let formatter=DateFormatter()
    formatter.dateFormat = "dd-MM-yyyy"
    return formatter.string(from: date)
}

class FinalViewController: UIViewController {

    @IBOutlet weak var picView: UIImageView!
    @IBOutlet weak var sitenameTextField: UILabel!
    @IBOutlet weak var discreptionTextField: UILabel!
    @IBOutlet weak var addtextField: UILabel!
    @IBOutlet weak var dateLabel: UILabel!
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }
    override func viewDidAppear(_ animated: Bool) {
        picView.image=locations.image
        sitenameTextField.text=locations.sitename
        discreptionTextField.text=locations.address
        addtextField.text=locations.discript
    dateLabel.text=getDate(date: locations.date)
        
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
