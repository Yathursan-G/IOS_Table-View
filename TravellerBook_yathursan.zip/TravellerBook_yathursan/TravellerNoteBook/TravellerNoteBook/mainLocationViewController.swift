//
//  mainLocationViewController.swift
//  TravellerNoteBook
//
//  Created by Yathursan Gunaratnam on 13/11/20.
//  Copyright © 2020 Yathursan Gunaratnam. All rights reserved.
//

import UIKit
func readData() -> [location]
{
    if UserDefaults.standard.value(forKey: "location") != nil
    {
        let data = UserDefaults.standard.value(forKey: "location") as! Data
        let loc = try! NSKeyedUnarchiver.unarchiveTopLevelObjectWithData(data) as! [location]
        return loc
    }
    else
    {
        return [location]()
    }
}
class mainLocationViewController: UIViewController, UIImagePickerControllerDelegate, UINavigationControllerDelegate {
    
    @IBOutlet weak var picView: UIImageView!
    @IBOutlet weak var sitenameTextField: UITextField!
    @IBOutlet weak var addressTextField: UITextField!
    
    @IBOutlet weak var discripTextField: UITextField!
    
    let date=Date()
    override func viewDidLoad() {
        super.viewDidLoad()
        
        UserDefaults.standard.removeObject(forKey: "location")
        
        // Do any additional setup after loading the view.
    }
    
    
    
    @IBAction func click(_ sender: Any) {
        let picker = UIImagePickerController()
        picker.allowsEditing = false
        picker.sourceType = .photoLibrary
        picker.delegate = self
        present(picker, animated: true, completion: nil)
    }
    func  imagePickerController(_ picker: UIImagePickerController, didFinishPickingMediaWithInfo info: [UIImagePickerController.InfoKey : Any]) {
        let image = info[.originalImage] as! UIImage
        picView.image = image
        dismiss(animated: true, completion: nil)
    }
    
    @IBAction func savedeatils(_ sender: UIButton) {
        let sitename=sitenameTextField.text!
        let address=addressTextField.text!
        let discript=discripTextField.text!
        let image=picView.image
        if(sitename.isEmpty)
        {
            alertMassage(msg: "Type site Name", controller: self)
        }
        else{
            
            let locations = location(sitename: sitename, address: address, image: image!, discript:discript, date:date)
            var loc=readData()
            loc.append(locations)
            let data = try! NSKeyedArchiver.archivedData(withRootObject: loc, requiringSecureCoding: false)
            UserDefaults.standard.set(data, forKey: "location")
            alertMassage(msg: "Data Save Succesfully", controller: self)
        }
    }
    /*
     // MARK: - Navigation
     
     // In a storyboard-based application, you will often want to do a little preparation before navigation
     override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
     // Get the new view controller using segue.destination.
     // Pass the selected object to the new view controller.
     }
     */
    
}
