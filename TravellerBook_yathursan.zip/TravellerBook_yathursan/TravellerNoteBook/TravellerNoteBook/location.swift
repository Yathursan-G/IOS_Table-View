//
//  location.swift
//  TravellerNoteBook
//
//  Created by Yathursan Gunaratnam on 10/11/20.
//  Copyright © 2020 Yathursan Gunaratnam. All rights reserved.
//

import Foundation
import UIKit
class location: NSObject, NSCoding {
    
    
    var sitename:String
    var address:String
    var image:UIImage
    var discript:String
    var date:Date
    init(sitename:String,address:String,image:UIImage,discript:String,date:Date) {
        self.sitename=sitename
        self.address=address
        self.image=image
        self.discript=discript
        self.date=date
    }
    func encode(with aCoder: NSCoder) {
        aCoder.encode(sitename,forKey: "sitename")
        aCoder.encode(address,forKey: "address")
        aCoder.encode(image,forKey: "image")
        aCoder.encode(discript,forKey: "discript")
        aCoder.encode(date,forKey: "date")
        
    }
    
    required init?(coder aDecoder: NSCoder) {
        self.sitename=aDecoder.decodeObject(forKey: "sitename") as! String
        self.address=aDecoder.decodeObject(forKey:"address") as! String
        self.image=aDecoder.decodeObject(forKey:"image") as! UIImage
        self.discript=aDecoder.decodeObject(forKey: "discript") as! String
        self.date=aDecoder.decodeObject(forKey: "date") as! Date
    }
    
}
